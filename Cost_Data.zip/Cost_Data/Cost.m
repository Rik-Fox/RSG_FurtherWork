Costs4 = table2struct(readtable('CostMini4For304050.csv'),'ToScalar',true);
Costs55 = table2struct(readtable('CostMini55For304050.csv'),'ToScalar',true);
Costs75 = table2struct(readtable('CostMini75For304050.csv'),'ToScalar',true);
Costs9 = table2struct(readtable('CostMini9For304050.csv'),'ToScalar',true);
CostsLABS = table2struct(readtable('CostMiniLABSFor304050.csv'),'ToScalar',true);


load('prevMean4.csv')
%prev4=prevs;

load('prevMean55.csv')
%pprev55=prevs;

load('prevMean75.csv')
%prev75=prevs;

load('prevMean9.csv')
%prev9=prevs;

load('prevMeanLABS.csv')
%prevLABS = prevs;



Costs4Yasa50 = zeros(1,floor(length(Costs4.Cost2050)/3));
Costs4Kwa50 = zeros(1,floor(length(Costs4.Cost2050)/3));
Costs4Mosa50 = zeros(1,floor(length(Costs4.Cost2050)/3));

Costs55Yasa50 = zeros(1,floor(length(Costs4.Cost2050)/3));
Costs55Kwa50 = zeros(1,floor(length(Costs4.Cost2050)/3));
Costs55Mosa50 = zeros(1,floor(length(Costs4.Cost2050)/3));

Costs75Yasa50 = zeros(1,floor(length(Costs4.Cost2050)/3));
Costs75Kwa50 = zeros(1,floor(length(Costs4.Cost2050)/3));
Costs75Mosa50 = zeros(1,floor(length(Costs4.Cost2050)/3));

Costs9Yasa50 = zeros(1,floor(length(Costs4.Cost2050)/3));
Costs9Kwa50 = zeros(1,floor(length(Costs4.Cost2050)/3));
Costs9Mosa50 = zeros(1,floor(length(Costs4.Cost2050)/3));

CostsLABSYasa50 = zeros(1,floor(length(Costs4.Cost2050)/3));
CostsLABSKwa50 = zeros(1,floor(length(Costs4.Cost2050)/3));
CostsLABSMosa50 = zeros(1,floor(length(Costs4.Cost2050)/3));

a=1;
for i=1:3:length(Costs4.Cost2050)

        Costs4Yasa50(a) = Costs4.Cost2050(i);
        Costs4Kwa50(a) = Costs4.Cost2050(i+1);
        Costs4Mosa50(a) = Costs4.Cost2050(i+2);
        
        Costs55Yasa50(a) = Costs55.Cost2050(i);
        Costs55Kwa50(a) = Costs55.Cost2050(i+1);
        Costs55Mosa50(a) = Costs55.Cost2050(i+2);
        
        Costs75Yasa50(a) = Costs75.Cost2050(i);
        Costs75Kwa50(a) = Costs75.Cost2050(i+1);
        Costs75Mosa50(a) = Costs75.Cost2050(i+2);
        
        Costs9Yasa50(a) = Costs9.Cost2050(i);
        Costs9Kwa50(a) = Costs9.Cost2050(i+1);
        Costs9Mosa50(a) = Costs9.Cost2050(i+2);
        
        Prev4Yasa50(a) = prevMean4(i,end);
        Prev4Kwa50(a) = prevMean4(i+1,end);
        Prev4Mosa50(a) = prevMean4(i+2,end);
        
        Prev55Yasa50(a) = prevMean55(i,end);
        Prev55Kwa50(a) = prevMean55(i+1,end);
        Prev55Mosa50(a) = prevMean55(i+2,end);
        
        Prev75Yasa50(a) = prevMean75(i,end);
        Prev75Kwa50(a) = prevMean75(i+1,end);
        Prev75Mosa50(a) = prevMean75(i+2,end);
        
        Prev9Yasa50(a) = prevMean9(i,end);
        Prev9Kwa50(a) = prevMean9(i+1,end);
        Prev9Mosa50(a) = prevMean9(i+2,end);
        


        a = a + 1;
end

b=1;
for i=1:3:length(CostsLABS.Cost2050)
    
    CostsLABSYasa50(b) = CostsLABS.Cost2050(i);
    CostsLABSKwa50(b) = CostsLABS.Cost2050(i+1);
    CostsLABSMosa50(b) = CostsLABS.Cost2050(i+2);
    
    PrevLABSYasa50(b) = prevMeanLABS(i,end);
    PrevLABSKwa50(b) = prevMeanLABS(i+1,end);
    PrevLABSMosa50(b) = prevMeanLABS(i+2,end);
    
    b = b + 1;
    
end

%save('COST50.mat',)

% Costs4Yasa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs4Kwa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs4Mosa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% 
% Costs55Yasa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs55Kwa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs55Mosa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% 
% Costs75Yasa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs75Kwa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs75Mosa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% 
% Costs9Yasa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs9Kwa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs9Mosa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% 
% CostsLABSYasa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% CostsLABSKwa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% CostsLABSMosa40 = zeros(1,floor(length(Costs4.Cost2050)/3));
% 
% a=1;
% for i=1:3:length(Costs4.Cost2040)
% 
%         Costs4Yasa40(a) = Costs4.Cost2040(i);
%         Costs4Kwa40(a) = Costs4.Cost2040(i+1);
%         Costs4Mosa40(a) = Costs4.Cost2040(i+2);
%         
%         Costs55Yasa40(a) = Costs55.Cost2040(i);
%         Costs55Kwa40(a) = Costs55.Cost2040(i+1);
%         Costs55Mosa40(a) = Costs55.Cost2040(i+2);
%         
%         Costs75Yasa40(a) = Costs75.Cost2040(i);
%         Costs75Kwa40(a) = Costs75.Cost2040(i+1);
%         Costs75Mosa40(a) = Costs75.Cost2040(i+2);
%         
%         Costs9Yasa40(a) = Costs9.Cost2040(i);
%         Costs9Kwa40(a) = Costs9.Cost2040(i+1);
%         Costs9Mosa40(a) = Costs9.Cost2040(i+2);
%         
%         CostsLABSYasa40(a) = CostsLABS.Cost2040(i);
%         CostsLABSKwa40(a) = CostsLABS.Cost2040(i+1);
%         CostsLABSMosa40(a) = CostsLABS.Cost2040(i+2);
% 
%         a = a + 1;
% end
% 
% 
% %save('COST40.mat','CostsIYasa40','CostsCYasa40','CostsIKwa40','CostsCKwa40','CostsIMosa40','CostsCMosa40')
% 
% Costs4Yasa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs4Kwa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs4Mosa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% 
% Costs55Yasa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs55Kwa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs55Mosa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% 
% Costs75Yasa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs75Kwa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs75Mosa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% 
% Costs9Yasa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs9Kwa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% Costs9Mosa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% 
% CostsLABSYasa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% CostsLABSKwa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% CostsLABSMosa30 = zeros(1,floor(length(Costs4.Cost2050)/3));
% 
% a=1;
% for i=1:3:length(Costs4.Cost2030)
% 
%         Costs4Yasa30(a) = Costs4.Cost2030(i);
%         Costs4Kwa30(a) = Costs4.Cost2030(i+1);
%         Costs4Mosa30(a) = Costs4.Cost2030(i+2);
%         
%         Costs55Yasa30(a) = Costs55.Cost2030(i);
%         Costs55Kwa30(a) = Costs55.Cost2030(i+1);
%         Costs55Mosa30(a) = Costs55.Cost2030(i+2);
%         
%         Costs75Yasa30(a) = Costs75.Cost2030(i);
%         Costs75Kwa30(a) = Costs75.Cost2030(i+1);
%         Costs75Mosa30(a) = Costs75.Cost2030(i+2);
%         
%         Costs9Yasa30(a) = Costs9.Cost2030(i);
%         Costs9Kwa30(a) = Costs9.Cost2030(i+1);
%         Costs9Mosa30(a) = Costs9.Cost2030(i+2);
%         
%         CostsLABSYasa30(a) = CostsLABS.Cost2030(i);
%         CostsLABSKwa30(a) = CostsLABS.Cost2030(i+1);
%         CostsLABSMosa30(a) = CostsLABS.Cost2030(i+2);
% 
%         a = a + 1;
% end

%save('COST30.mat','CostsIYasa30','CostsCYasa30','CostsIKwa30','CostsCKwa30','CostsIMosa30','CostsCMosa30')

%% prev vs cost 

s=100;
p(1) = figure(1);
hold on
scatter(Prev4Yasa50,Costs4Yasa50,s,'DisplayName','0.4')
scatter(Prev55Yasa50,Costs55Yasa50,s,'DisplayName','0.55')
scatter(Prev75Yasa50,Costs75Yasa50,s,'DisplayName','0.75')
scatter(Prev9Yasa50,Costs9Yasa50,s,'DisplayName','0.9')
scatter(PrevLABSYasa50(1:4),CostsLABSYasa50(1:4),s,'x','DisplayName','0.4 TL')
scatter(PrevLABSYasa50(5:8),CostsLABSYasa50(5:8),s,'x','DisplayName','0.55 TL')
scatter(PrevLABSYasa50(9:12),CostsLABSYasa50(9:12),s,'x','DisplayName','0.75 TL')
scatter(PrevLABSYasa50(13:16),CostsLABSYasa50(13:16),s,'x','DisplayName','0.9 TL')
scatter(PrevLABSYasa50(17:20),CostsLABSYasa50(17:20),s,'p','DisplayName','0.4 iELISA')
scatter(PrevLABSYasa50(21:24),CostsLABSYasa50(21:24),s,'p','DisplayName','0.55 iELISA')
scatter(PrevLABSYasa50(25:28),CostsLABSYasa50(25:28),s,'p','DisplayName','0.75 iELISA')
scatter(PrevLABSYasa50(29:32),CostsLABSYasa50(29:32),s,'p','DisplayName','0.9 iELISA')
legend
savefig('MiniPrevCostYasa')


p(2) = figure(2);
hold on
scatter(Prev4Kwa50,Costs4Kwa50,s,'DisplayName','0.4')
scatter(Prev55Kwa50,Costs55Kwa50,s,'DisplayName','0.55')
scatter(Prev75Kwa50,Costs75Kwa50,s,'DisplayName','0.75')
scatter(Prev9Kwa50,Costs9Kwa50,s,'DisplayName','0.9')
scatter(PrevLABSKwa50(1:4),CostsLABSKwa50(1:4),s,'x','DisplayName','0.4 TL')
scatter(PrevLABSKwa50(5:8),CostsLABSKwa50(5:8),s,'x','DisplayName','0.55 TL')
scatter(PrevLABSKwa50(9:12),CostsLABSKwa50(9:12),s,'x','DisplayName','0.75 TL')
scatter(PrevLABSKwa50(13:16),CostsLABSKwa50(13:16),s,'x','DisplayName','0.9 TL')
scatter(PrevLABSKwa50(17:20),CostsLABSKwa50(17:20),s,'p','DisplayName','0.4 iELISA')
scatter(PrevLABSKwa50(21:24),CostsLABSKwa50(21:24),s,'p','DisplayName','0.55 iELISA')
scatter(PrevLABSKwa50(25:28),CostsLABSKwa50(25:28),s,'p','DisplayName','0.75 iELISA')
scatter(PrevLABSKwa50(29:32),CostsLABSKwa50(29:32),s,'p','DisplayName','0.9 iELISA')
legend
savefig('MiniPrevCostKwa')


p(3) = figure(3);
hold on
scatter(Prev4Mosa50,Costs4Mosa50,s,'DisplayName','0.4')
scatter(Prev55Mosa50,Costs55Mosa50,s,'DisplayName','0.55')
scatter(Prev75Mosa50,Costs75Mosa50,s,'DisplayName','0.75')
scatter(Prev9Mosa50,Costs9Mosa50,s,'DisplayName','0.9')
scatter(PrevLABSMosa50(1:4),CostsLABSMosa50(1:4),s,'x','DisplayName','0.4 TL')
scatter(PrevLABSMosa50(5:8),CostsLABSMosa50(5:8),s,'x','DisplayName','0.55 TL')
scatter(PrevLABSMosa50(9:12),CostsLABSMosa50(9:12),s,'x','DisplayName','0.75 TL')
scatter(PrevLABSMosa50(13:16),CostsLABSMosa50(13:16),s,'x','DisplayName','0.9 TL')
scatter(PrevLABSMosa50(17:20),CostsLABSMosa50(17:20),s,'p','DisplayName','0.4 iELISA')
scatter(PrevLABSMosa50(21:24),CostsLABSMosa50(21:24),s,'p','DisplayName','0.55 iELISA')
scatter(PrevLABSMosa50(25:28),CostsLABSMosa50(25:28),s,'p','DisplayName','0.75 iELISA')
scatter(PrevLABSMosa50(29:32),CostsLABSMosa50(29:32),s,'p','DisplayName','0.9 iELISA')
legend
savefig('MiniPrevCostMosa')


% % figure(5)
% % 
% % p(1) = subplot(3,1,1);
% % hold on
% % scatter(I_30(1:30,2,3),Costs55Kwa30(1:30))
% % scatter(I_30(31:60,2,3),Costs55Kwa30(31:60))
% % scatter(I_30(61:90,2,3),Costs4Kwa30(1:30))
% % scatter(I_30(91:120,2,3),Costs4Kwa30(31:60))
% % legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% % 
% % 
% % 
% % p(2) = subplot(3,1,2);
% % hold on
% % scatter(I_40(1:30,2,3),CostsIKwa40(1:30))
% % scatter(I_40(31:60,2,3),CostsIKwa40(31:60))
% % scatter(I_40(61:90,2,3),Costs4Kwa50(1:30))
% % scatter(I_40(91:120,2,3),Costs4Kwa50(31:60))
% % legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% % 
% % 
% % 
% % p(3) = subplot(3,1,3);
% % hold on
% % scatter(I_end(1:30,2,3),CostsIKwa50(1:30))
% % scatter(I_end(31:60,2,3),CostsIKwa50(31:60))
% % scatter(I_end(61:90,2,3),Costs4Kwa50(1:30))
% % scatter(I_end(91:120,2,3),Costs4Kwa50(31:60))
% % legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% % 
% % 
% % title(p(1),'2030')
% % title(p(2),'2040')
% % title(p(3),'2050')
% % 
% % savefig('PrevCostKwa')
% % 
% % figure(6)
% % 
% % p(1) = subplot(3,1,1);
% % hold on
% % scatter(I_30(1:30,3,3),Costs55Mosa30(1:30))
% % scatter(I_30(31:60,3,3),Costs55Mosa30(31:60))
% % scatter(I_30(61:90,3,3),Costs4Mosa30(1:30))
% % scatter(I_30(91:120,3,3),Costs4Mosa30(31:60))
% % legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% % 
% % p(2) = subplot(3,1,2);
% % hold on
% % scatter(I_40(1:30,3,3),CostsIMosa40(1:30))
% % scatter(I_40(31:60,3,3),CostsIMosa40(31:60))
% % scatter(I_40(61:90,3,3),Costs4Mosa50(1:30))
% % scatter(I_40(91:120,3,3),Costs4Mosa50(31:60))
% % legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% % 
% % 
% % p(3) = subplot(3,1,3);
% % hold on
% % scatter(I_end(1:30,3,3),CostsIMosa50(1:30))
% % scatter(I_end(31:60,3,3),CostsIMosa50(31:60))
% % scatter(I_end(61:90,3,3),Costs4Mosa50(1:30))
% % scatter(I_end(91:120,3,3),Costs4Mosa50(31:60))
% % legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% % 
% % title(p(1),'2030')
% % title(p(2),'2040')
% % title(p(3),'2050')
% % 
% % savefig('PrevVsCostMosa')
% 
% %% reported prev vs cost
% 
% figure(7)
% 
% p(1) = subplot(3,1,1);
% hold on
% scatter(Cases_30(1:30,1,3),Costs55Yasa30(1:30))
% scatter(Cases_30(31:60,1,3),Costs55Yasa30(31:60))
% scatter(Cases_30(61:90,1,3),Costs4Yasa30(1:30))
% scatter(Cases_30(91:120,1,3),Costs4Yasa30(31:60))
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% p(2) = subplot(3,1,2);
% hold on
% scatter(Cases_40(1:30,1,3),CostsIYasa40(1:30))
% scatter(Cases_40(31:60,1,3),CostsIYasa40(31:60))
% scatter(Cases_40(61:90,1,3),Costs4Yasa50(1:30))
% scatter(Cases_40(91:120,1,3),Costs4Yasa50(31:60))
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% p(3) = subplot(3,1,3);
% hold on
% scatter(Cases_end(1:30,1,3),CostsIYasa50(1:30))
% scatter(Cases_end(31:60,1,3),CostsIYasa50(31:60))
% scatter(Cases_end(61:90,1,3),Costs4Yasa50(1:30))
% scatter(Cases_end(91:120,1,3),Costs4Yasa50(31:60))
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% title(p(1),'2030')
% title(p(2),'2040')
% title(p(3),'2050')
% 
% savefig('ReportedVsCostYasa')
% 
% figure(8)
% 
% 
% p(1) = subplot(3,1,1);
% hold on
% scatter(Cases_30(1:30,2,3),Costs55Kwa30(1:30))
% scatter(Cases_30(31:60,2,3),Costs55Kwa30(31:60))
% scatter(Cases_30(61:90,2,3),Costs4Kwa30(1:30))
% scatter(Cases_30(91:120,2,3),Costs4Kwa30(31:60))
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% p(2) = subplot(3,1,2);
% hold on
% scatter(Cases_40(1:30,2,3),CostsIKwa40(1:30))
% scatter(Cases_40(31:60,2,3),CostsIKwa40(31:60))
% scatter(Cases_40(61:90,2,3),Costs4Kwa50(1:30))
% scatter(Cases_40(91:120,2,3),Costs4Kwa50(31:60))
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% p(3) = subplot(3,1,3);
% hold on
% scatter(Cases_end(1:30,2,3),CostsIKwa50(1:30))
% scatter(Cases_end(31:60,2,3),CostsIKwa50(31:60))
% scatter(Cases_end(61:90,2,3),Costs4Kwa50(1:30))
% scatter(Cases_end(91:120,2,3),Costs4Kwa50(31:60))
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% title(p(1),'2030')
% title(p(2),'2040')
% title(p(3),'2050')
% 
% savefig('ReportedVsCostKwa')
% 
% figure(9)
% 
% p(1) = subplot(3,1,1);
% hold on
% scatter(Cases_30(1:30,3,3),Costs55Mosa30(1:30))
% scatter(Cases_30(31:60,3,3),Costs55Mosa30(31:60))
% scatter(Cases_30(61:90,3,3),Costs4Mosa30(1:30))
% scatter(Cases_30(91:120,3,3),Costs4Mosa30(31:60))
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% p(2) = subplot(3,1,2);
% hold on
% scatter(Cases_40(1:30,3,3),CostsIMosa40(1:30))
% scatter(Cases_40(31:60,3,3),CostsIMosa40(31:60))
% scatter(Cases_40(61:90,3,3),Costs4Mosa50(1:30))
% scatter(Cases_40(91:120,3,3),Costs4Mosa50(31:60))
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% p(3) = subplot(3,1,3);
% hold on
% scatter(Cases_end(1:30,3,3),CostsIMosa50(1:30))
% scatter(Cases_end(31:60,3,3),CostsIMosa50(31:60))
% scatter(Cases_end(61:90,3,3),Costs4Mosa50(1:30))
% scatter(Cases_end(91:120,3,3),Costs4Mosa50(31:60))
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% title(p(1),'2030')
% title(p(2),'2040')
% title(p(3),'2050')
% 
% savefig('ReportedVsCostMosa')
% 
% %% under/over reporting
% 
% figure(10)
% hold on
% scatter(I_end(1:30,1,3),Cases_end(1:30,1,3))
% scatter(I_end(31:60,1,3),Cases_end(31:60,1,3))
% scatter(I_end(61:90,1,3),Cases_end(61:90,1,3))
% scatter(I_end(91:120,1,3),Cases_end(91:120,1,3))
% plot(linspace(5,9)*1e-3,linspace(5,9)*1e-3)
% axis([5e-3 9e-3 5e-3 9e-3])
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% savefig('UnderOverYasa')
% 
% figure(11)
% hold on
% scatter(I_end(1:30,2,3),Cases_end(1:30,2,3))
% scatter(I_end(31:60,2,3),Cases_end(31:60,2,3))
% scatter(I_end(61:90,2,3),Cases_end(61:90,2,3))
% scatter(I_end(91:120,2,3),Cases_end(91:120,2,3))
% plot(linspace(2,5)*1e-3,linspace(2,5)*1e-3)
% axis([2e-3 5e-3 2e-3 5e-3])
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% savefig('UnderOverKwa')
% 
% figure(12)
% hold on
% scatter(I_end(1:4,3,3),Cases_end(1:4,3,3))
% scatter(I_end(5:8,3,3),Cases_end(5:8,3,3))
% scatter(I_end(9:12,3,3),Cases_end(9:12,3,3))
% scatter(I_end(13:16,3,3),Cases_end(13:16,3,3))
% plot(linspace(0,4)*1e-4,linspace(0,4)*1e-4)
% axis([0e-4 4e-4 0e-4 4e-4])
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% savefig('UnderOverMosa')
% 
% %% prev vs reported prev
% 
% figure(13)
% 
% subplot(2,1,1)
% hold on
% scatter(Cases_end(1:30,1,3),CostsIYasa50(1:30))
% scatter(Cases_end(31:60,1,3),CostsIYasa50(31:60))
% scatter(Cases_end(61:90,1,3),Costs4Yasa50(1:30))
% scatter(Cases_end(91:120,1,3),Costs4Yasa50(31:60))
% axis([5.5e-3 8.7e-3 1e6 5e6])
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% subplot(2,1,2)
% hold on
% scatter(I_end(1:30,1,3),CostsIYasa50(1:30))
% scatter(I_end(31:60,1,3),CostsIYasa50(31:60))
% scatter(I_end(61:90,1,3),Costs4Yasa50(1:30))
% scatter(I_end(91:120,1,3),Costs4Yasa50(31:60))
% axis([5.5e-3 8.7e-3 1e6 5e6])
% legend('ITM CATT','ITM RDT','Checce CATT','Checce RDT')
% 
% savefig('CompareYasa')
